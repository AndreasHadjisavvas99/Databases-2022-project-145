package Panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class main_panel extends  JFrame{
    public JPanel main_panel;
    private JButton btnPanel1;
    private JButton btnPanel2;


    public main_panel()  {
        btnPanel1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(new panel1().panel1);
                setSize(300,300);
                setVisible(true);
            }
        });
        btnPanel2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(new panel2().panel2);
                setSize(300,300);
                setVisible(true);
            }
        });
    }
}
