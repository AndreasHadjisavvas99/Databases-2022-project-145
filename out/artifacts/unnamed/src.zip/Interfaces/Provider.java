package Interfaces;

public interface Provider {
    String _cs = "jdbc:postgresql://localhost:5432/test_database",
            _user = "postgres",
            _pwd = "mustaki124";
}
